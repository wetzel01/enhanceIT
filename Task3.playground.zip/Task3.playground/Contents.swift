import UIKit

var strs = ["flower", "flow", "flight"]

longestCommonPrefix(words: strs)

func longestCommonPrefix(words: [String]){
    let wordsSize = words.count
    var internalWords = words
    
    if wordsSize == 0 || wordsSize == 1 {
        print("")
    }
    
    internalWords.sort()
    let firstMin = internalWords[0].count
    let lastMin = internalWords[wordsSize-1].count
    
    let minVal = min(firstMin,lastMin)
    
    var index = 0
    
    while index < minVal && String(internalWords[0][internalWords[0].index(internalWords[0].startIndex, offsetBy: index)]) == String(internalWords[wordsSize-1][internalWords[wordsSize-1].index(internalWords[wordsSize-1].startIndex, offsetBy: index)]) {
        index += 1
    }
    if(index == 0){
        print("No Prefix in Common")
    }else {
        let wordIndex = internalWords[0].index(internalWords[0].startIndex, offsetBy: index-1)
        
        print(internalWords[0][...wordIndex])
    }
}
