//
//  ViewController.swift
//  WetzelCalculator
//
//  Created by Consultant on 8/19/22.
//

import UIKit

class ViewController: UIViewController {
    var valueHolder:String = ""
    var firstValue:String = ""
    var operand:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var operationDisplayLabel: UILabel!
    
    
    @IBAction func onDivisionClick() {
        if valueHolder == "" || valueHolder == "0" {
            operationDisplayLabel.text = "Connot Divide Zero!"
        } else {
            operand = "division"
            firstValue = valueHolder
            valueHolder = ""
            operationDisplayLabel.text = valueHolder
        }
    }
    
    @IBAction func onPlusClick() {
        if valueHolder == "" || valueHolder == "0" {
            valueHolder = "0"
        } else {
            operand = "plus"
            firstValue = valueHolder
            valueHolder = ""
            operationDisplayLabel.text = valueHolder
        }
    }
    
    @IBAction func onMinusClick() {
        if valueHolder == "" || valueHolder == "0" {
            valueHolder = "0"
        } else {
            operand = "minus"
            firstValue = valueHolder
            valueHolder = ""
            operationDisplayLabel.text = valueHolder
        }
    }
    
    @IBAction func onMultiplyClick() {
        if valueHolder == "" || valueHolder == "0" {
            valueHolder = "0"
        } else {
            operand = "multiply"
            firstValue = valueHolder
            valueHolder = ""
            operationDisplayLabel.text = valueHolder
        }
    }
    
    @IBAction func onOneClick() {
        valueHolder.append("1")
        operationDisplayLabel.text = valueHolder
    }
    
    
    @IBAction func onTwoClick() {
        valueHolder.append("2")
        operationDisplayLabel.text = valueHolder
    }
    
    @IBAction func onThreeClick() {
        valueHolder.append("3")
        operationDisplayLabel.text = valueHolder
    }
    
    
    @IBAction func onFourClick() {
        valueHolder.append("4")
        operationDisplayLabel.text = valueHolder
    }
    
    
    @IBAction func onFiveClick() {
        valueHolder.append("5")
        operationDisplayLabel.text = valueHolder
    }
    
    
    @IBAction func onSixClick() {
        valueHolder.append("6")
        operationDisplayLabel.text = valueHolder
    }
    
    @IBAction func onSevenClick() {
        valueHolder.append("7")
        operationDisplayLabel.text = valueHolder
    }
    
    @IBAction func onEightClick() {
        valueHolder.append("8")
        operationDisplayLabel.text = valueHolder
    }
    
    @IBAction func onNineClick() {
        valueHolder.append("9")
        operationDisplayLabel.text = valueHolder
    }
    
    
    @IBAction func onZeroClick() {
        if valueHolder != "" {
            valueHolder.append("0")
            operationDisplayLabel.text = valueHolder
        }
    }
    
    @IBAction func onCClick() {
        valueHolder = ""
        operationDisplayLabel.text = valueHolder
    }
    
    @IBAction func onDotClick() {
        if valueHolder == "" {
            valueHolder.append("0.")
        }else{
            valueHolder.append(".")
        }
        
        operationDisplayLabel.text = valueHolder
    }
    
    
    @IBAction func onEqualsClick() {
        var result:String = ""
        var res:Double = 0.0
        //var response = 0
        let value1: Double = Double(firstValue) ?? 0.0
        let value2: Double = Double(valueHolder) ?? 0.0
        if firstValue == "" {
            operationDisplayLabel.text = "0"
        } else if operand != "" {
    
            switch operand {
            case "division" :
                
                res = value1 / value2
                
                if floor(res) == res {
                    result = String(Int(res))
                } else {
                    result = String(res)
                }
                
                valueHolder = result
                operationDisplayLabel.text = result
            case "plus" :
                
                res = value1 + value2
                
                if floor(res) == res {
                    result = String(Int(res))
                } else {
                    result = String(res)
                }
                
                valueHolder = result
                operationDisplayLabel.text = result
            case "minus" :
                res = value1 - value2
                
                if floor(res) == res {
                    result = String(Int(res))
                } else {
                    result = String(res)
                }
                
                valueHolder = result
                operationDisplayLabel.text = result
            case "multiply" :
                res = value1 * value2
                
                if floor(res) == res {
                    result = String(Int(res))
                } else {
                    result = String(res)
                }
                
                valueHolder = result
                operationDisplayLabel.text = result
            default:
                operationDisplayLabel.text = "Operand not set"
            }
        }
    }
}
