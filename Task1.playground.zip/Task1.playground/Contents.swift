import UIKit

var input = "()"
var inputBroken = Array(input).enumerated()
var stack = [Character]()
var result = ""

var open = ["(","[","{"]
var close = [")","]","}"]
var equivalences: [Character: Character] = [")":"(","]":"[","}":"{"]

for (indx,elemnt) in inputBroken {
    if indx == 0 {
        if !open.contains(String(elemnt)) {
            result = "false"
        } else {
            stack.append(elemnt)
        }
        continue
    }
    
    if open.contains(String(elemnt)) {
        stack.append(elemnt)
    } else {
        if stack.popLast() == equivalences[elemnt]{
            continue
        }else {
            result = "false"
        }
    }
}

if result == "" {
    result = "true"
}

print(result)
