import UIKit

var nums = [2,7,11,15]
var val = 9
var result = [Int]()

for (primmaryIndex,element) in nums.enumerated(){
    for (secondaryIndex,secondelemment) in nums.enumerated(){
        if element == secondelemment{
            continue
        }
        
        if element + secondelemment == val && (!result.contains(primmaryIndex) || !result.contains(secondaryIndex)){
            result.append(primmaryIndex)
            result.append(secondaryIndex)
        }
    }
}

print(result)
